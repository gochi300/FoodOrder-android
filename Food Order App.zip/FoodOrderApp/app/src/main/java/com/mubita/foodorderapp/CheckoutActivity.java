package com.mubita.foodorderapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.mubita.foodorderapp.adapters.CartListAdapter;
import com.mubita.foodorderapp.adapters.CheckoutListAdapter;
import com.mubita.foodorderapp.adapters.OrderListAdapter;
import com.mubita.foodorderapp.adapters.ProductsAdapter;
import com.mubita.foodorderapp.api.ApiClient;
import com.mubita.foodorderapp.api.ApiInterface;
import com.mubita.foodorderapp.models.Order;
import com.mubita.foodorderapp.models.Product;
import com.mubita.foodorderapp.viewmodel.OrderViewModel;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {

    private ApiInterface apiInterface;
    // **
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private Button btnConfirm;
    // **
    private OrderViewModel orderViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        /*RecyclerView*/
        mRecyclerView = findViewById(R.id.recycler_view);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(CheckoutActivity.this, LinearLayoutManager.VERTICAL, false);
        dividerItemDecoration = new DividerItemDecoration(CheckoutActivity.this, DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(dividerItemDecoration);
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter
        mAdapter = new CheckoutListAdapter(CheckoutActivity.this, AppDataStore.getInstance().getProductList());
        mRecyclerView.setAdapter(mAdapter);

        btnConfirm = findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessageDriverAlert ();
            }
        });


        List<String> stringList = new ArrayList<>();
        stringList.add("Paypal");
        stringList.add("Cash");

        Spinner spinnerAssets = findViewById(R.id.spinner_filter);
        spinnerAssets.setAdapter(new ArrayAdapter<>( this,R.layout.support_simple_spinner_dropdown_item, stringList));
    }

    public void showMessageDriverAlert () {
        AlertDialog alertDialog = new AlertDialog.Builder(CheckoutActivity.this).create();
        alertDialog.setTitle("Place order");
        alertDialog.setMessage("Place order for K0.00");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE,"Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        List<Product> productList = AppDataStore.getInstance().getProductList();

                        Timestamp timestamp = new Timestamp(System.currentTimeMillis());

                        //traverse arrayList and save to db
                        ArrayList<Order> orderArrayList = new ArrayList<Order>();

                        for (Product product: productList)
                        {
                            int productId = product.getId();
                            String productName = product.getProductName();
                            Integer productPrice = product.getProductPrice();
                            Integer productQty = product.getProductQty();
                            /**/
                            Order order = new Order( productId, productName , timestamp.getTime(), 1, productQty, productPrice, "pending" );
                            orderViewModel = ViewModelProviders.of(CheckoutActivity.this).get(OrderViewModel.class);
                            orderViewModel.insert(order);

                            orderArrayList.add(order);

                        }

                        postOrder(orderArrayList);
                        Toast.makeText(CheckoutActivity.this, "Your order has been placed!", Toast.LENGTH_SHORT).show();
                        // **
                        AppDataStore.getInstance().getProductList().clear();
                        dialog.dismiss();
                        // **
                        startActivity(new Intent(CheckoutActivity.this, MainActivity.class));
                    }
                });
        alertDialog.show();
    }

    public void postOrder(List<Order> orderList){

        // **
        apiInterface = ApiClient.getInstance().create(ApiInterface.class);

        Call<List<Order>> call = apiInterface.postOrder(orderList);
        //Call<Order> call = apiInterface.postOrder(orders);

        call.enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response) {
                //Toast.makeText(CartActivity.this, "Your order has been posted!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t) {
                Toast.makeText(CheckoutActivity.this, "There was a problem!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
