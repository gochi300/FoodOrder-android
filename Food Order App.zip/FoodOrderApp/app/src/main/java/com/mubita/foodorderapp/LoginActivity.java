package com.mubita.foodorderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mubita.foodorderapp.models.User;

public class LoginActivity extends AppCompatActivity {

    private EditText mobileNumberEditText, passwordEditText;
    private Button loginBtn, registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mobileNumberEditText = findViewById(R.id.editText1);
        passwordEditText = findViewById(R.id.editText2);

        loginBtn = findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mobileNumber = mobileNumberEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                // **
                attemptLogin(mobileNumber, password);
                // **
                //bypassLogin();
            }
        });

        registerBtn = findViewById(R.id.registerBtn);
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    private void attemptLogin(String mobileNumber, String password) {
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
    }

    private void bypassLogin() {
        User user = new User();
        user.setId(1);
        user.setFullName("John Doe");
        user.setNrcNumber("123456/78/9");
        user.setDateOfBirth("01/09/1993");
        user.setMobileNumber("0977123456");
        user.setEmailAddress("johnDoe@gmail.com");

        // save user to dataStore
        AppDataStore.getInstance().setUser(user);

        startActivity(new Intent(LoginActivity.this, MainActivity.class));
    }

}
